// Libraries
import React from 'react';

// Components
import SaleManager from '../components/SaleManager';

const NewOrder = () => {

    return (
        <SaleManager />
    )
};

NewOrder.propTypes = {};

export default NewOrder;